# Change Log
* 1.2: January 31, 2017 *
- Added option to enable featured item's excerpt and post date to be shown
- In menu editor, added fields for excerpt and post date. Pulls item's defaults if they exist.
- Convert $sidebar to function to clean up template files
- Users can specify theme specific templates by creating a `/hero-menu/[filename].php` file in their themes folder and calling `<?php putHeroMenu('[filename]'); ?>` in their `header.php` file

* 1.1: December 7, 2016 *
- Added default call to action text as input placeholder
- Made title a link in templates
- Updated admin menu UI

* 1.0: November 1, 2016 *
- Initial Release